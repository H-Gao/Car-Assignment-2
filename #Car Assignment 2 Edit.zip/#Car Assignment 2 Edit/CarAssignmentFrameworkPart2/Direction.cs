﻿/// <summary>
/// Used for the car's direction
/// </summary>
public enum Direction
{
    Up,
    Left,
    Down,
    Right
}
